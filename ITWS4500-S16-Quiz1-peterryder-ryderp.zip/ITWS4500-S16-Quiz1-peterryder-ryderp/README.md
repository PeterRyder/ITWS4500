Quiz 1 Server
==============

A simple server for Quiz 1
Peter Ryder