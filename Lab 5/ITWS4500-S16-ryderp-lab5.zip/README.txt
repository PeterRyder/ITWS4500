Peter Ryder
Lab 5

This lab made me sad. It was pretty difficult to get information
from Angular, that being the input text, into Node. It was then
difficult to get inforamtion from Node, that being the twitter
data, back into Angular. Because of this reason, I started using
socket.io in an attempt to pipe the information back and forth 
between these two systems, and it didn't work out in the end.

I believe I have all of the pieces needed to complete this lab,
however it is not all functional. Last lab went fine for me using
Angular, but now trying to tie and Angular model with Node was rather
difficult.